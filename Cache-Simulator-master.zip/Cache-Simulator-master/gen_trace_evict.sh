echo "Creating trace file for eviction"
make -f testcase_makefile trace_evict

./trace_evict
