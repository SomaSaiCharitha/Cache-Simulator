echo "Creating trace file for LRU test"
make -f testcase_makefile trace_lru_test

./trace_lru_test
