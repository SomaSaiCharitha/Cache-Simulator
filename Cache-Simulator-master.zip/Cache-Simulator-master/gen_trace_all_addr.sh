echo "Creating trace file for all addresses"
make -f testcase_makefile trace_all_addr

./trace_all_addr
